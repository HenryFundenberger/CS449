# Henry Fundenberger
# Student ID: 16251041
# CS 449

'''
This is the main file for the SOS game. It contains a refernce to the GUI class which is the main class for the game.
Running this file will load the GUI and start the game logic.
'''

from GUI import App

if __name__ == "__main__":
    app = App()
    app.mainloop()
